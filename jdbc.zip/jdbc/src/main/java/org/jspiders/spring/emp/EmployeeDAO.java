package org.jspiders.spring.emp;

public interface EmployeeDAO 
{
	public int create(Employee emp);
	
	public int update(Employee emp);
	
	public int delete(int empno);
}
