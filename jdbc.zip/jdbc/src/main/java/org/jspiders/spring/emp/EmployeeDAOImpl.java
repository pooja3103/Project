package org.jspiders.spring.emp;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDAOImpl implements EmployeeDAO
{
	private JdbcTemplate jdbc;
	
	@Override
	public int create(Employee emp) 
	{
		String query = "insert into employee "
				+ "values(?,?,?)";
		int result = getJdbc().update(query,emp.getEmpno(),emp.getEname(),emp.getSalary());		
		return result;
	}
	
	@Override
	public int update(Employee emp)
	{
		String query = " update employee "
				+ " set ename = ? , salary = ? "
				+ " where empno = ? ";
		
		int result = getJdbc().update(query,emp.getEname(),emp.getSalary(),emp.getEmpno());		
		return result;
	}
	
	@Override
	public int delete(int empno)
	{
		String query = " delete from employee "
				+ " where empno = ? ";
		
		int result = getJdbc().update(query,empno);		
		return result;
	}

	public JdbcTemplate getJdbc() {
		return jdbc;
	}

	public void setJdbc(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

}
