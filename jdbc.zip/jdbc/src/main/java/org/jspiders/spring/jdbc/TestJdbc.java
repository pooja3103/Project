package org.jspiders.spring.jdbc;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class TestJdbc 
{
	public static void main(String[] args)
	{
		ClassPathXmlApplicationContext context = null; 
		context = new ClassPathXmlApplicationContext("org/jspiders/spring/jdbc/config.xml");
		
		JdbcTemplate jdbc = (JdbcTemplate) context.getBean("jdbcTemplate");
		
		String query = "insert into student "
				+ "values(?,?)";
		int result = jdbc.update(query, 111,"pooja");
		System.out.println("Number of records inserted are : " +result);

		if(context!=null)
		{
			context.close();
		}
	}
}
