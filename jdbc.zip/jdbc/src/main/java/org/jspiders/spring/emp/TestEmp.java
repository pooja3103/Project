package org.jspiders.spring.emp;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmp 
{
	public static void main(String[] args) 
	{
		ClassPathXmlApplicationContext context = null; 
		context = new ClassPathXmlApplicationContext("org/jspiders/spring/emp/config.xml");
		
		EmployeeDAOImpl empimpl = (EmployeeDAOImpl) context.getBean("empDAO");
		
//		Employee emp = (Employee) context.getBean("emp");
	
//		int result = empimpl.create(emp);
//		int result = empimpl.update(emp);
		
		int result = empimpl.delete(900);
		
		System.out.println("Number of records deleted are : " +result);

		if(context!=null)
		{
			context.close();
		}
	}

}
