package com.jspiders.firstproject.mvc;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController
{
	@RequestMapping("register")
	public ModelAndView register()
	{
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("userReg");
		return modelAndView;
	}
	
	@Autowired
	UserDAO dao;
	
	@RequestMapping(value = "registerUser" , method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute("user")User user)
	{
		dao.insert(user);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("displayUser");
		modelAndView.addObject("User" ,user);
		return modelAndView;
	}

	@RequestMapping(value = "viewUser")
	public ModelAndView viewUser(ModelAndView model) throws IOException
	{
		List<User> list = dao.retrieve();
		model.setViewName("viewUser");
		model.addObject("list",list);
		return model;
	}
}
