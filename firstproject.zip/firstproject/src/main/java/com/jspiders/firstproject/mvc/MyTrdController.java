package com.jspiders.firstproject.mvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyTrdController
{
	@RequestMapping("displayObject")
	public ModelAndView objectType()
	{
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("object");
		
		Person person = new Person();
		person.setId(121);
		person.setName("pooja");
		person.setContact(6789646645l);
		modelAndView.addObject("Person", person);
		return modelAndView;
	}
}
