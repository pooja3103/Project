package com.jspiders.firstproject.mvc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class UserDAO 
{
	private JdbcTemplate jdbc;
	
	public int insert(User user) 
	{
		String query = "insert into user "
				+ "values(?,?,?,?)";
		int result = getJdbc().update(query,user.getId(),user.getName(),user.getEmail(),user.getPassword());		
		return result;
	}
	
	public List<User> retrieve() 
	{
		List<User> list = jdbc.query("select * from user", new RowMapper<User>(){
			public User mapRow(ResultSet rs,int rowNum) throws SQLException{
				User u1 = new User();
				u1.setId(rs.getInt("id"));
				u1.setName(rs.getString("name"));
				u1.setEmail(rs.getString("email"));
				u1.setPassword(rs.getString("password"));
				return u1;
			}
		});
		return list;	
	}

	public JdbcTemplate getJdbc() {
		return jdbc;
	}
	public void setJdbc(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}
}
