package com.jspiders.firstproject.mvc;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyFrthController 
{
	@RequestMapping("displayCollection")
	public ModelAndView collectionType()
	{

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("collection");
		
		Person p1 = new Person();
		p1.setId(121);
		p1.setName("pooja");
		p1.setContact(6789646645l);
		
		Person p2 = new Person();
		p2.setId(122);
		p2.setName("priya");
		p2.setContact(9987766466l);
		
		Person p3 = new Person();
		p3.setId(123);
		p3.setName("priyani");
		p3.setContact(9987766666l);
		
		ArrayList<Person> persons = new ArrayList<Person>();
		persons.add(p1);
		persons.add(p2);
		persons.add(p3);
		
		modelAndView.addObject("Persons", persons);
		return modelAndView;
	}
}
