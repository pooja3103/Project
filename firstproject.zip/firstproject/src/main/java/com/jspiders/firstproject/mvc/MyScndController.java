package com.jspiders.firstproject.mvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyScndController
{
	@RequestMapping("displayPrimitive")
	public ModelAndView primitiveType()
	{

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("primitive");
		
		modelAndView.addObject("Id", 101);
		modelAndView.addObject("Name","pooja");
		modelAndView.addObject("Contact",678546340);
		return modelAndView;
	}
}
